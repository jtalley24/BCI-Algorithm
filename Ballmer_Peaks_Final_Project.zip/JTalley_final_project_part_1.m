%% Final project part 1
% Prepared by John Bernabei and Brittany Scheid

% Author: John Talley
% Collabrator: Joseph Iwasyk

% One of the oldest paradigms of BCI research is motor planning: predicting
% the movement of a limb using recordings from an ensemble of cells involved
% in motor control (usually in primary motor cortex, often called M1).

% This final project involves predicting finger flexion using intracranial EEG (ECoG) in three human
% subjects. The data and problem framing come from the 4th BCI Competition. For the details of the
% problem, experimental protocol, data, and evaluation, please see the original 4th BCI Competition
% documentation (included as separate document). The remainder of the current document discusses
% other aspects of the project relevant to BE521.


%% Start the necessary ieeg.org sessions (0 points)

% username = 'jtalley';
% passPath = 'jta_ieeglogin.bin';

% Load training ecog from each of three patients
% s1_train_ecog = IEEGSession('I521_Sub1_Training_ecog', username, passPath);

% Load training dataglove finger flexion values for each of three patients
% s1_train_dg = IEEGSession('I521_Sub1_Training_dg', username, passPath);
addpath('C:\Users\Jack\Documents\Penn\BE 521\Final_Project_Part1');
load('C:\Users\Jack\Documents\Penn\BE 521\Final_Project_Part1\final_proj_part1_data.mat');
load('C:\Users\Jack\Documents\Penn\BE 521\Final_Project_Part1\testRfunction.mat');
load('C:\Users\Jack\Documents\Penn\BE 521\Final_Project_Part1\leaderboard_data.mat');

dg1 = train_dg{1};
dg2 = train_dg{2};
dg3 = train_dg{3};

ecog1 = train_ecog{1};
ecog1 = ecog1(:,[1:5,10,15:28,34:47]);
ecog2 = train_ecog{2};
ecog2 = ecog2(:,[7:13,15:29,31,34:36,38,43,45:46]);
ecog3 = train_ecog{3};
ecog3 = ecog3(:,[7:29,34:35,41,44,46,48:49,51,54:55,57,61]);

leader_ecog1 = leaderboard_ecog{1};
leader_ecog1(:,55) = []; % remove bad channel 55
leader_ecog1 = leader_ecog1(:,[1:5,10,15:28,34:47]);
leader_ecog2 = leaderboard_ecog{2};
leader_ecog2(:,[21,38]) = []; % remove bad channels 21 and 37
leader_ecog2 = leader_ecog2(:,[7:13,15:29,31,34:36,38,43,45:46]);
leader_ecog3 = leaderboard_ecog{3};
leader_ecog3 = leader_ecog3(:,[7:29,34:35,41,44,46,48:49,51,54:55,57,61]);


% phase shift 37 ms to ECoG to account for amplifier delay
ecog1(38:end,:) = ecog1(1:end-37,:);
ecog2(38:end,:) = ecog2(1:end-37,:);
ecog3(38:end,:) = ecog3(1:end-37,:);

leader_ecog1(38:end,:) = leader_ecog1(1:end-37,:);
leader_ecog2(38:end,:) = leader_ecog2(1:end-37,:);
leader_ecog3(38:end,:) = leader_ecog3(1:end-37,:);

%% Extract dataglove and ECoG data %1.1

% Dataglove should be (samples x 5) array 
% ECoG should be (samples x channels) array

%1.1
% 300,000 samples 
Fs = 1000; % Hz
% Nyquist: 500 hz

% Splitting Training/Testing at 70/30
% 
train_dg1 = dg1(1:210000,:);
train_dg2 = dg2(1:210000,:);
train_dg3 = dg3(1:210000,:);

test_dg1 = dg1(210001:300000,:);
test_dg2 = dg2(210001:300000,:);
test_dg3 = dg3(210001:300000,:);

train_ecog1 = ecog1(1:210000,:);
train_ecog2 = ecog2(1:210000,:);
train_ecog3 = ecog3(1:210000,:);

test_ecog1 = ecog1(210001:300000,:);
test_ecog2 = ecog2(210001:300000,:);
test_ecog3 = ecog3(210001:300000,:);

% REVERSE
% % % % 
% train_dg1 = dg1(90001:300000,:);
% train_dg2 = dg2(90001:300000,:);
% train_dg3 = dg3(90001:300000,:);
% 
% test_dg1 = dg1(1:90000,:);
% test_dg2 = dg2(1:90000,:);
% test_dg3 = dg3(1:90000,:);
% 
% train_ecog1 = ecog1(90001:300000,:);
% train_ecog2 = ecog2(90001:300000,:);
% train_ecog3 = ecog3(90001:300000,:);
% 
% test_ecog1 = ecog1(1:90000,:);
% test_ecog2 = ecog2(1:90000,:);
% test_ecog3 = ecog3(1:90000,:);


% Split data into a train and test set (use at least 50% for training)

%% Filter raw ECoG data %1.2

%1.2

% train_ecog1_bp = bandpass(train_ecog1, [0.15 200], Fs);
% train_ecog2_bp = bandpass(train_ecog2, [0.15 200], Fs);
% train_ecog3_bp = bandpass(train_ecog3, [0.15 200], Fs);
% 
% test_ecog1_bp = bandpass(test_ecog1, [0.15 200], Fs);
% test_ecog2_bp = bandpass(test_ecog2, [0.15 200], Fs);
% test_ecog3_bp = bandpass(test_ecog3, [0.15 200], Fs);

% butter

% [b,a] = butter(3,[0.0003 0.4],'bandpass'); %3rd order, 0.15/Nyquist:200/Nyquist

% 0.15 Hz to 200 Hz used as in BCI competition doc

train_ecog1_ff = filter_data(train_ecog1);
train_ecog2_ff = filter_data(train_ecog2);
train_ecog3_ff = filter_data(train_ecog3);

test_ecog1_ff = filter_data(test_ecog1);
test_ecog2_ff = filter_data(test_ecog2);
test_ecog3_ff = filter_data(test_ecog3);

%% Get Features
% run getWindowedFeats_release function
%% 2.1

window_length = 0.100; % seconds
window_overlap = 0.050; % seconds
len = 300000;

NumWins = @(xLen, Fs, winLen, winDisp) round((xLen/Fs - winLen)/winDisp + 1);
numWindows = NumWins(len, Fs, window_length, window_overlap);
numTrainWindows = NumWins(size(train_dg1,1), Fs, window_length, window_overlap);
numTestWindows = NumWins(size(test_dg1,1), Fs, window_length, window_overlap);

% Features:
% 1. LMP Feature
% 2. Frequency Ranges
% 3. CAR (all papers)
% 4. Spectrogram 
% 5. Conv
% 6. Power in different freq bands
% 7. LL
% 8. Area
% 9. Energy
% 10. Zx
% 11. Average time-domain voltage
% 12. Average freq-domain magnitude in consecutive 15 Hz bands
% 13. Spike counts (paper)


%% 2.2

features_1 = get_features(ecog1, Fs);

%% 2.3

windowed_feats1 = getWindowedFeats(ecog1, Fs, window_length, window_overlap);
windowed_feats2 = getWindowedFeats(ecog2, Fs, window_length, window_overlap);
windowed_feats3 = getWindowedFeats(ecog3, Fs, window_length, window_overlap);

train_windowed_feats1 = getWindowedFeats(train_ecog1, Fs, window_length, window_overlap);
train_windowed_feats2 = getWindowedFeats(train_ecog2, Fs, window_length, window_overlap);
train_windowed_feats3 = getWindowedFeats(train_ecog3, Fs, window_length, window_overlap);

test_windowed_feats1 = getWindowedFeats(test_ecog1, Fs, window_length, window_overlap);
test_windowed_feats2 = getWindowedFeats(test_ecog2, Fs, window_length, window_overlap);
test_windowed_feats3 = getWindowedFeats(test_ecog3, Fs, window_length, window_overlap);

% Leaderboard data windowed features
leader_windowed_feats1 = getWindowedFeats(leader_ecog1, Fs, window_length, window_overlap);
leader_windowed_feats2 = getWindowedFeats(leader_ecog2, Fs, window_length, window_overlap);
leader_windowed_feats3 = getWindowedFeats(leader_ecog3, Fs, window_length, window_overlap);

%% 3.1

% M (total number of time bins) x (features*channels* N (time bins))
% = 5999 x (6*61*3) + 1 for leftmost column of 1s
% = 5999 x 1099

%% Create R matrix 3.2 
% run create_R_matrix
N_wind = 10;
R = create_R_matrix(testR_features, N_wind);

% test construction of Response Matrix

r_mean = mean(mean(R)); % 25.4668 confirmed

R1 = create_R_matrix(windowed_feats1, N_wind);
R1_train = create_R_matrix(train_windowed_feats1, N_wind);
R1_test = create_R_matrix(test_windowed_feats1, N_wind);
R1_leader = create_R_matrix(leader_windowed_feats1, N_wind);

R2 = create_R_matrix(windowed_feats2, N_wind);
R2_train = create_R_matrix(train_windowed_feats2, N_wind);
R2_test = create_R_matrix(test_windowed_feats2, N_wind);
R2_leader = create_R_matrix(leader_windowed_feats2, N_wind);

R3 = create_R_matrix(windowed_feats3, N_wind);
R3_train = create_R_matrix(train_windowed_feats3, N_wind);
R3_test = create_R_matrix(test_windowed_feats3, N_wind);
R3_leader = create_R_matrix(leader_windowed_feats3, N_wind);

% try upsampling R-matrices before linear decoding

%% 4.1
% calculate linear filter f
% f = (R'*R)^-1*(R'*Y)

% downsample method 1 (use MovingWinFeats method)

x_start = 1;

winLen = Fs*window_length;
winDisp = Fs*window_overlap;

dg1_ds_avg = zeros(numWindows, size(dg1,2));
dg2_ds_avg = zeros(numWindows, size(dg2,2));
dg3_ds_avg = zeros(numWindows, size(dg3,2));

for i = 1:numWindows
    x_end = winLen + (i-1)*winDisp;

    dg1_wind = dg1(x_start:x_end, :);
    dg1_ds_avg(i,:) = mean(dg1_wind);
    
    dg2_wind = dg2(x_start:x_end, :);
    dg2_ds_avg(i,:) = mean(dg2_wind);
    
    dg3_wind = dg3(x_start:x_end, :);
    dg3_ds_avg(i,:) = mean(dg3_wind);
    
    x_start = x_end - (winLen - winDisp) + 1;
end

x_start = 1;

train_dg1_ds_avg = zeros(numTrainWindows, size(dg1,2));
train_dg2_ds_avg = zeros(numTrainWindows, size(dg2,2));
train_dg3_ds_avg = zeros(numTrainWindows, size(dg3,2));

for i = 1:numTrainWindows
    x_end = winLen + (i-1)*winDisp;

    dg1_wind = train_dg1(x_start:x_end, :);
    train_dg1_ds_avg(i,:) = mean(dg1_wind);
    
    dg2_wind = train_dg2(x_start:x_end, :);
    train_dg2_ds_avg(i,:) = mean(dg2_wind);
    
    dg3_wind = train_dg3(x_start:x_end, :);
    train_dg3_ds_avg(i,:) = mean(dg3_wind);
    
    x_start = x_end - (winLen - winDisp) + 1;
end

x_start = 1;

test_dg1_ds_avg = zeros(numTestWindows, size(dg1,2));
test_dg2_ds_avg = zeros(numTestWindows, size(dg2,2));
test_dg3_ds_avg = zeros(numTestWindows, size(dg3,2));

for i = 1:numTestWindows
    x_end = winLen + (i-1)*winDisp;

    dg1_wind = test_dg1(x_start:x_end, :);
    test_dg1_ds_avg(i,:) = mean(dg1_wind);
    
    dg2_wind = test_dg2(x_start:x_end, :);
    test_dg2_ds_avg(i,:) = mean(dg2_wind);
    
    dg3_wind = test_dg3(x_start:x_end, :);
    test_dg3_ds_avg(i,:) = mean(dg3_wind);
    
    x_start = x_end - (winLen - winDisp) + 1;
end

Y1 = dg1_ds_avg;
Y2 = dg2_ds_avg;
Y3 = dg3_ds_avg;

Y1_train = train_dg1_ds_avg;
Y2_train = train_dg2_ds_avg;
Y3_train = train_dg3_ds_avg;


% downsample method 2: decimate

% for i = 1:5
%     Y1(:,i) = decimate(dg1(:,i),window_overlap*Fs);
%     Y1_train(:,i) = decimate(train_dg1(:,i),window_overlap*Fs);
%     
%     Y2(:,i) = decimate(dg2(:,i),window_overlap*Fs);
%     Y2_train(:,i) = decimate(train_dg2(:,i),window_overlap*Fs);
%     
%     Y3(:,i) = decimate(dg3(:,i),window_overlap*Fs);
%     Y3_train(:,i) = decimate(train_dg3(:,i),window_overlap*Fs);
% end
% 
% Y1(size(Y1,1),:) = [];
% Y1_train(size(Y1_train,1),:) = [];
% Y2(size(Y2,1),:) = [];
% Y2_train(size(Y2_train,1),:) = [];
% Y3(size(Y3,1),:) = [];
% Y3_train(size(Y3_train,1),:) = [];



% Y1_test = test_dg1_ds_avg;
% Y2_test = test_dg2_ds_avg;
% Y3_test = test_dg3_ds_avg;

f1 = mldivide(R1'*R1, R1'*Y1);
f2 = mldivide(R2'*R2, R2'*Y2);
f3 = mldivide(R3'*R3, R3'*Y3);

Model = cell(3,1);
Model{1} = f1;
Model{2} = f2;
Model{3} = f3;
% 
f1_train = mldivide(R1_train'*R1_train, R1_train'*Y1_train);
f2_train = mldivide(R2_train'*R2_train, R2_train'*Y2_train);
f3_train = mldivide(R3_train'*R3_train, R3_train'*Y3_train);

Y1_hat = R1_test*f1_train;
Y1_hat(size(R1_test,1)+1,:) = Y1_hat(size(R1_test,1),:);
% Y1_hat(size(R1_test,1)+2,:) = Y1_hat(size(R1_test,1),:);

Y2_hat = R2_test*f2_train;
Y2_hat(size(R2_test,1)+1,:) = Y2_hat(size(R2_test,1),:);
% Y2_hat(size(R2_test,1)+2,:) = Y2_hat(size(R2_test,1),:);

Y3_hat = R3_test*f3_train;
Y3_hat(size(R3_test,1)+1,:) = Y3_hat(size(R3_test,1),:);
% Y3_hat(size(R3_test,1)+2,:) = Y3_hat(size(R3_test,1),:);

% % Test leaderboard_data.mat data

% Y1_hat = R1_leader*f1;
% Y1_hat(size(R1_leader,1)+1,:) = Y1_hat(size(R1_leader,1),:);
% 
% Y2_hat = R2_leader*f2;
% Y2_hat(size(R2_leader,1)+1,:) = Y2_hat(size(R2_leader,1),:);
% 
% Y3_hat = R3_leader*f3;
% Y3_hat(size(R3_leader,1)+1,:) = Y3_hat(size(R3_leader,1),:);

% try upsampling R matrix first and going straight to ML model

%% Train classifiers (8 points)


% Classifier 1: Get angle predictions using optimal linear decoding. That is, 
% calculate the linear filter (i.e. the weights matrix) as defined by 
% Equation 1 for all 5 finger angles.


% Try at least 1 other type of machine learning algorithm, you may choose
% to loop through the fingers and train a separate classifier for angles 
% corresponding to each finger



% Try a form of either feature or prediction post-processing to try and
% improve underlying data or predictions.



%% Correlate data to get test accuracy and make figures (2 point)

% Calculate accuracy by correlating predicted and actual angles for each
% finger separately. Hint: You will want to use zointerp to ensure both 
% vectors are the same length.

% upsample predictions

zoInterp = @(x,numInterp) reshape(repmat(x,numInterp,1),1,length(x)*numInterp);
Y1_hat_up = zeros(size(test_ecog1,1),size(test_dg1,2));
Y2_hat_up = zeros(size(test_ecog2,1),size(test_dg2,2));
Y3_hat_up = zeros(size(test_ecog3,1),size(test_dg3,2));

for i = 1:5
    Y1_hat_up(:,i) = zoInterp(Y1_hat(:,i)', window_overlap*Fs);
    Y2_hat_up(:,i) = zoInterp(Y2_hat(:,i)', window_overlap*Fs);
    Y3_hat_up(:,i) = zoInterp(Y3_hat(:,i)', window_overlap*Fs);
end

[rho1, pval1] = corr(Y1_hat_up, test_dg1);
[rho2, pval2] = corr(Y2_hat_up, test_dg2);
[rho3, pval3] = corr(Y3_hat_up, test_dg3);

rho1_avg = (rho1(1,1)+rho1(2,2)+rho1(3,3)+rho1(5,5))/4;
rho2_avg = (rho2(1,1)+rho2(2,2)+rho2(3,3)+rho2(5,5))/4;
rho3_avg = (rho3(1,1)+rho3(2,2)+rho3(3,3)+rho3(5,5))/4;
rho_avg = (rho1(1,1)+rho1(2,2)+rho1(3,3)+rho1(5,5)+rho2(1,1)+rho2(2,2)+rho2(3,3)+rho2(5,5)+rho3(1,1)+rho3(2,2)+rho3(3,3)+rho3(5,5))/12;

% Get Leaderboard predictions

% zoInterp = @(x,numInterp) reshape(repmat(x,numInterp,1),1,length(x)*numInterp);
% Y1_hat_up = zeros(size(leader_ecog1,1),size(dg1,2));
% Y2_hat_up = zeros(size(leader_ecog2,1),size(dg2,2));
% Y3_hat_up = zeros(size(leader_ecog3,1),size(dg3,2));
% 
% for i = 1:5
%     Y1_hat_up(:,i) = zoInterp(Y1_hat(:,i)', 50);
%     Y2_hat_up(:,i) = zoInterp(Y2_hat(:,i)', 50);
%     Y3_hat_up(:,i) = zoInterp(Y3_hat(:,i)', 50);
% end
% 
% % create predicted_dg{} array
% predicted_dg = cell(3,1);
% predicted_dg{1} = Y1_hat_up;
% predicted_dg{2} = Y2_hat_up;
% predicted_dg{3} = Y3_hat_up;

%% Other ML Model 4.2
% Try logistic regression classifier

% logistic regression classifier function

% B = mnrfit(R1_train,Y1_train); % coefficients
% % training error (percentage);
% probs = mnrval(B,R1_train);
% 
% [~,Ytrain] = max(probs,[],2);
% training_error = 100*((length(train_class) - sum(Ytrain == train_class))/length(train_class));
% 
% % testing error (percentage);
% probabilities = mnrval(B,testFeatsZ);
% 
% [~,Ytest] = max(probabilities,[],2);
% test_error = 100*((length(test_class) - sum(Ytest == test_class))/length(test_class));

% Try SVM
% 
% SVM_model = fitcsvm(R1_train,Y1_train(:,1),'KernelFunction','RBF');
% SVM_train = predict(SVM_model, R1_train);
% 
% SVM_test = predict(SVM_model, testFeatsZ);
% SVM_test_error = 100*((length(test_class) - sum(SVM_test == test_class))/length(test_class));

% Try fitrsvm model
% 
% Mdl = fitrsvm(R1_train,Y1_train(:,1));
% yfit = predict(Mdl,R1_train);

% Try Gaussian Process Regression Model (with both windowed_features and R matrices)
% Try fitrensemble model
% 
% ypred1 = zeros(size(Y1_test,1),size(Y1_test,2));
% ypred2 = zeros(size(Y2_test,1),size(Y2_test,2));
% ypred3 = zeros(size(Y3_test,1),size(Y3_test,2));
% 
% for i =1:5
%     treeMdl_1 = fitrensemble(R1_train,Y1_train(:,i));
% %     gprMdl_1 = fitrgp(R1_train,Y1_train(:,i));
% %     ypred1(:,i) = predict(gprMdl_1,R1_train);
%     ypred1(:,i) = predict(treeMdl_1,R1_test);
%     
%     treeMdl_2 = fitrensemble(R2_train,Y2_train(:,i));
% %     gprMdl_2 = fitrgp(R2_train,Y2_train(:,i));
% %     ypred2(:,i) = predict(gprMdl_2,R2_train);
%     ypred2(:,i) = predict(treeMdl_2,R2_test);
%     
%     treeMdl_3 = fitrensemble(R3_train,Y3_train(:,i));
% %     gprMdl_3 = fitrgp(R3_train,Y3_train(:,i));
% %     ypred3(:,i) = predict(gprMdl_3,R3_train);
%     ypred3(:,i) = predict(treeMdl_3,R3_test);
% end
% 
% ypred1(size(R1_test,1)+1,:) = ypred1(size(R1_test,1),:);
% ypred2(size(R2_test,1)+1,:) = ypred2(size(R2_test,1),:);
% ypred3(size(R3_test,1)+1,:) = ypred3(size(R3_test,1),:);
% 
% % upsample predictions
% 
% zoInterp = @(x,numInterp) reshape(repmat(x,numInterp,1),1,length(x)*numInterp);
% ypred1_up = zeros(size(test_dg1,1),size(test_dg1,2));
% ypred2_up = zeros(size(test_dg2,1),size(test_dg2,2));
% ypred3_up = zeros(size(test_dg3,1),size(test_dg3,2));
% 
% for i = 1:5
%     ypred1_up(:,i) = zoInterp(ypred1(:,i)', 50);
%     ypred2_up(:,i) = zoInterp(ypred2(:,i)', 50);
%     ypred3_up(:,i) = zoInterp(ypred3(:,i)', 50);
% end
% 
% [rho1_g, pval1_g] = corr(ypred1_up, test_dg1);
% [rho2_g, pval2_g] = corr(ypred2_up, test_dg2);
% [rho3_g, pval3_g] = corr(ypred3_up, test_dg3);

%% Results 4.3

% PREDICTION VS ACTUAL ANGLE PLTOTED FOR BEST LINEAR DECODER CORRELATION
% AND BEST RANDOM TREES CORRELATION FOR ALL 3 SUBJECTS

% figure;
% plot(Y1_hat_up(:,1));
% hold on;
% plot(test_dg1(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 1: Predicted vs. Actual Angles for Testing Set (Linear Decoder)');
% legend('Predicted','Actual','Location','northwest');
% 
% figure;
% plot(Y2_hat_up(:,1));
% hold on;
% plot(test_dg2(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 2: Predicted vs. Actual Angles for Testing Set (Linear Decoder)');
% legend('Predicted','Actual','Location','southeast');
% 
% figure;
% plot(Y3_hat_up(:,1));
% hold on;
% plot(test_dg3(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 3: Predicted vs. Actual Angles for Testing Set (Linear Decoder)');
% legend('Predicted','Actual');
% 
% figure;
% plot(ypred1_up(:,1));
% hold on;
% plot(test_dg1(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 1: Predicted vs. Actual Angles for Testing Set (Random Trees)');
% legend('Predicted','Actual','Location','southwest');
% 
% figure;
% plot(ypred2_up(:,1));
% hold on;
% plot(test_dg2(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 2: Predicted vs. Actual Angles for Testing Set (Random Trees)');
% legend('Predicted','Actual','Location','southwest');
% 
% figure;
% plot(ypred3_up(:,1));
% hold on;
% plot(test_dg3(:,1));
% xlabel('Time (ms)');
% ylabel('Angle (rads)');
% title('Subject 3: Predicted vs. Actual Angles for Testing Set (Random Trees)');
% legend('Predicted','Actual','Location','northwest');


% CORRELATIONS TRIAL 1 (All 3 subjects, 4 features, All samples (NOT split by
% testing/training sets... this is a "dummy" correlation trial)

% Subject 1:
% finger 1: 0.5979
% finger 2: 0.5785
% finger 3: 0.4956
% finger 4: 0.5971
% finger 5: 0.5300

% Subject 2:
% finger 1: 0.5889
% finger 2: 0.4799
% finger 3: 0.5212
% finger 4: 0.5482
% finger 5: 0.4657

% Subject 3:
% finger 1: 0.7432
% finger 2: 0.7230
% finger 3: 0.6661
% finger 4: 0.7263
% finger 5: 0.6811

% CORRELATIONS TRIAL 2 (All 3 subjects, 4 features, trained on R-matrix 
% LINEAR DECODER for train/test)

% Subject 1:
% finger 1: 0.3652
% finger 2: 0.2851
% finger 3: 0.0939
% finger 4: 0.3880
% finger 5: 0.0471

% Subject 2:
% finger 1: 0.3176
% finger 2: 0.2291
% finger 3: 0.1460
% finger 4: 0.2563
% finger 5: 0.1461

% Subject 3:
% finger 1: 0.4913
% finger 2: 0.3035
% finger 3: 0.3343
% finger 4: 0.4490
% finger 5: 0.3728

% CORRELATIONS TRIAL 3 (All 3 subjects, 6 features, trained on R-matrix 
% LINEAR DECODER for train/test)

% Subject 1:
% finger 1: 0.3238
% finger 2: 0.3310
% finger 3: 0.0533
% finger 4: 0.3578
% finger 5: 0.0708

% Subject 2:
% finger 1: 0.2765
% finger 2: 0.1810
% finger 3: 0.1636
% finger 4: 0.2503
% finger 5: 0.1220

% Subject 3:
% finger 1: 0.4448
% finger 2: 0.2833
% finger 3: 0.3090
% finger 4: 0.4005
% finger 5: 0.3449

% CORRELATIONS TRIAL 4 (All 3 subjects, 6 features, trained on R-matrix and
% dataglove training data with FITRENSEMBLE regresion tree ensemble model)

% Subject 1:
% finger 1: 0.1697
% finger 2: 0.2795
% finger 3: 0.0340
% finger 4: 0.2086
% finger 5: -0.0596

% Subject 2:
% finger 1: 0.1405
% finger 2: 0.1094
% finger 3: 0.0729
% finger 4: 0.1783
% finger 5: 9.8e-4

% Subject 3:
% finger 1: 0.3751
% finger 2: 0.1927
% finger 3: 0.2841
% finger 4: 0.2485
% finger 5: 0.1821

% CORRELATIONS TRIAL 5 (All 3 subjects, 6 features, trained on R-matrix 
% LINEAR DECODER for train/test + PHASE SHIFT 37 ms ECOG)

% Subject 1:
% finger 1: 0.3697
% finger 2: 0.2851
% finger 3: 0.1177
% finger 4: 0.3832
% finger 5: 0.0777

% Subject 2:
% finger 1: 0.2864
% finger 2: 0.1848
% finger 3: 0.1719
% finger 4: 0.2160
% finger 5: 0.1450

% Subject 3:
% finger 1: 0.4988
% finger 2: 0.3315
% finger 3: 0.3302
% finger 4: 0.4098
% finger 5: 0.3957

% CORRELATIONS TRIAL 6 (All 3 subjects, 6 features, trained on R-matrix and
% dataglove training data with FITRENSEMBLE regresion tree ensemble model 
% + PHASE SHIFT 37 ms)
% 
% Subject 1:
% finger 1: 0.2534
% finger 2: 0.2763
% finger 3: 0.0874
% finger 4: 0.2558
% finger 5: -0.0056

% Subject 2:
% finger 1: 0.2438
% finger 2: 0.1703
% finger 3: 0.0808
% finger 4: 0.1719
% finger 5: -0.0220

% Subject 3:
% finger 1: 0.3676
% finger 2: 0.1935
% finger 3: 0.2907
% finger 4: 0.3082
% finger 5: 0.1942

% CORRELATIONS TRIAL 7 (All 3 subjects, ONLY energy feature, trained on R-matrix and
% LINEAR DECODER for train/test + PHASE SHIFT 37 ms ECOG, bandpass filter switched to 65-200 Hz)
% 
% Subject 1:
% finger 1: 0.5164
% finger 2: 0.6030
% finger 3: 0.0992
% finger 4: 0.5489
% finger 5: 0.1261

% Subject 2:
% finger 1: 0.4899
% finger 2: 0.2250
% finger 3: 0.2625
% finger 4: 0.4477
% finger 5: 0.2903

% Subject 3:
% finger 1: 0.5894
% finger 2: 0.4529
% finger 3: 0.5126
% finger 4: 0.4940
% finger 5: 0.4989

% CORRELATIONS TRIAL 8 (All 3 subjects, ONLY energy feature, trained on R-matrix and
% LINEAR DECODER for train/test + PHASE SHIFT 37 ms ECOG, bandpass filter switched to 65-200 Hz
% + CAR re-referenced signal)
% rho_avg: 0.4250

% CORRELATIONS TRIAL 9 (All 3 subjects, ONLY energy feature, trained on R-matrix and
% LINEAR DECODER for train/test + PHASE SHIFT 37 ms ECOG, bandpass filter switched to 65-200 Hz
% + CAR re-referenced signal + N_wind = 10 instead of 3)
% rho_avg: 0.4642
